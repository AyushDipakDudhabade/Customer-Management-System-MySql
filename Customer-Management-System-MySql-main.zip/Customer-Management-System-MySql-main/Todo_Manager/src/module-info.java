/**
 * 
 */
/**
 * @author Admin
 *
 */
module Todo_Manager {
	requires java.sql;
}